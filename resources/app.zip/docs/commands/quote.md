# 📚 Quote Command

The **quote** command displays a random quote from a book or an author. You can specify a book or an author to get a quote from.
If you use the _--all_ option, it will display all the quotes from the specified book or author.

This commands serves as example and guide for creating new commands.

## Usage

```bash
{app.name} quote [--book=] [--author=] [--all]
```

## Options

 - _book_: The book to get the quote from
 - _author_: The author to get the quote from
 - _all_: Display all quotes that match the given criteria

## Examples
To get a quote from a book:

```bash
{app.name} quote --book="The Call of Cthulhu"
```

To get a quote from an author:

```bash
{app.name} quote --author=howard
```

To get all quotes from a book:

```bash
{app.name} quote --book="The Call of Cthulhu" --all
```
