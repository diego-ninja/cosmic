<?php

declare(strict_types=1);

use Ninja\Cosmic\Application\Application;
use Ninja\Cosmic\Environment\Env;
use Ninja\Cosmic\Terminal\Terminal;

return static function (): Application {
    Terminal::loadThemes(Env::basePath("vendor/diego-ninja/cosmic/themes"));
    if (is_dir(Env::basePath("themes"))) {
        Terminal::loadThemes(Env::basePath("themes"));
    }
    Terminal::enableTheme(Env::get("APP_THEME", "default"));

    $app = new Application(
        name: sprintf("%s %s", Terminal::getTheme()->getAppIcon(), Env::get("APP_NAME")),
        version: Env::appVersion()
    );

    $app->setAutoExit(false);

    return $app;
};
