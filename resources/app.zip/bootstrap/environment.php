<?php

declare(strict_types=1);

$dotenv = is_phar() ?
    Dotenv\Dotenv::createMutable(Phar::running()) :
    Dotenv\Dotenv::createMutable(getcwd());

$dotenv->safeLoad();
