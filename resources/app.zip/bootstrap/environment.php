<?php

declare(strict_types=1);

use function Cosmic\find_env;
use function Cosmic\is_phar;

$env_file = find_env();
$dotenv = is_phar() ?
    Dotenv\Dotenv::createMutable(Phar::running(), $env_file) :
    Dotenv\Dotenv::createMutable(getcwd(), $env_file);

$dotenv->safeLoad();
