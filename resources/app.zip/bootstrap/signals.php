<?php

declare(strict_types=1);

use Innmind\Signals\Info;
use Innmind\Signals\Signal;
use Ninja\Cosmic\Application\Application;
use Ninja\Cosmic\Event\Lifecycle;
use Ninja\Cosmic\Signal\SignalHandler;
use Ninja\Cosmic\Terminal\Terminal;


SignalHandler::listen([Signal::interrupt, Signal::terminate], static function (Signal $signal, Info $info): void {
    Lifecycle::dispatchLifecycleEvent(Application::LIFECYCLE_APP_SIGNALED, ["signal" => $signal, "info" => $info]);
    Terminal::output()->writeln("\n\n 💔 <error>Interrupted by user.</error>");
    Terminal::restoreCursor();

    exit($signal->toInt());
});
