<?php

declare(strict_types=1);

use Ninja\Cosmic\Application\Application;
use Ninja\Cosmic\Command\CommandInterface;
use Ninja\Cosmic\Event\Lifecycle;
use Ramsey\Uuid\Uuid;

(static function (): void {
    Lifecycle::withLifecycleId(Uuid::uuid7());
    Lifecycle::registerLifecycleEvents([
        Application::LIFECYCLE_APP_BOOT,
        Application::LIFECYCLE_APP_SHUTDOWN,
        Application::LIFECYCLE_APP_BUILD,
        Application::LIFECYCLE_APP_INSTALL,
        CommandInterface::LIFECYCLE_COMMAND_RUN,
        CommandInterface::LIFECYCLE_COMMAND_SUCCESS,
        CommandInterface::LIFECYCLE_COMMAND_FAILURE,
        CommandInterface::LIFECYCLE_COMMAND_ERROR
    ]);
})();
