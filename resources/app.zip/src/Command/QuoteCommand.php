<?php

declare(strict_types=1);

namespace {app.root}\App\Command;

use Exception;
use Ninja\Cosmic\Command\Attribute\Alias;
use Ninja\Cosmic\Command\Attribute\Description;
use Ninja\Cosmic\Command\Attribute\Icon;
use Ninja\Cosmic\Command\Attribute\Name;
use Ninja\Cosmic\Command\Attribute\Option;
use Ninja\Cosmic\Command\Attribute\Signature;
use Ninja\Cosmic\Command\CosmicCommand;
use Ninja\Cosmic\Terminal\Terminal;
use function Termwind\render;

#[Icon("📚")]
#[Name('quote')]
#[Signature('quote [--book=] [--author=] [--all]')]
#[Description('Display a random quote from a book or an author')]
#[Alias("tell")]
#[Option("--book", "The book to get a quote from")]
#[Option("--author", "The author to get a quote from")]
#[Option("--all", "Get all the quotes from the author or book")]
final class QuoteCommand extends CosmicCommand
{
    private const QUOTES = [
        "howard" => [
            "Supernatural Horror in Literature" => [
                "The oldest and strongest emotion of mankind is fear, and the oldest and strongest kind of fear is fear of the unknown.",
                "The true weird tale has something more than secret murder, bloody bones, or a sheeted form clanking chains according to rule. A certain atmosphere of breathless and unexplainable dread of outer, unknown forces must be present; and there must be a hint, expressed with a seriousness and portentousness becoming its subject, of that most terrible conception of the human brain—a malign and particular suspension or defeat of those fixed laws of Nature which are our only safeguard against the assaults of chaos and the daemons of unplumbed space.",
                "In his house at R'lyeh, dead Cthulhu waits dreaming.",
                "The world is indeed comic, but the joke is on mankind.",
                "The universe is full of magical things, patiently waiting for our wits to grow sharper."
            ],
            "The Call of Cthulhu" => [
                "That is not dead which can eternal lie, and with strange aeons, even death may die.",
                "The most merciful thing in the world, I think, is the inability of the human mind to correlate all its contents.",
                "The world is indeed comic, but the joke is on mankind.",
                "We live on a placid island of ignorance in the midst of black seas of infinity, and it was not meant that we should voyage far.",
                "I never ask a man what his business is, for it never interests me. What I ask him about are his thoughts and dreams."
            ],
            "The Nameless City" => [
                "That which is not dead can eternal lie, and with strange aeons, even death may die.",
                "What has risen may sink, and what has sunk may rise."
            ],
            "The Dunwich Horror" => [
                "The Old Ones were, the Old Ones are, and the Old Ones shall be. Not in the spaces we know, but between them, they walk serene and primal, undimensioned and to us unseen.",
                "When age fell upon the world, and wonder went out of the minds of men; when grey cities reared to smoky skies tall towers grim and ugly, in whose shadow none might dream of the sun or of spring’s flowering meads; when learning stripped earth of her mantle of beauty, and poets sang no more save of twisted phantoms seen with bleared and inward-looking eyes; when these things had come to pass, and childish hopes had gone away forever, there was a man who traveled out of life on a quest into the spaces whither the world’s dreams had fled."
            ],
            "The Shadow over Innsmouth" => [
                "From even the greatest of horrors irony is seldom absent.",
                "I could not write about ‘ordinary people’ because I am not in the least interested in them. Without interest there can be no art. Man’s relations to man do not captivate my fancy. It is man’s relations to the cosmos—to the unknown—which alone arouse in me the spark of creative imagination.",
                "When you have seen as much of life as I have, you will not underestimate the power of obsessive love."
            ],
            "Letter to Rheinhart Kleiner" => [
                "I could not write about ‘ordinary people’ because I am not in the least interested in them. Without interest there can be no art. Man’s relations to man do not captivate my fancy. It is man’s relations to the cosmos—to the unknown—which alone arouse in me the spark of creative imagination."
            ],
            "The Tomb" => [
                "I have seen beyond the bounds of infinity and drawn down daemons from the stars. . . . I have harnessed the shadows that stride from world to world to sow death and madness. . . .",
                "Searchers after horror haunt strange, far places.",
                "In his house at R'lyeh, dead Cthulhu waits dreaming."
            ]
        ],
        "edgar" => [
            "The Raven" => [
                "Once upon a midnight dreary, while I pondered, weak and weary...",
                "Quoth the Raven, 'Nevermore.'",
                "Deep into that darkness peering, long I stood there wondering, fearing, doubting, dreaming dreams no mortal ever dared to dream before.",
                "And the silken, sad, uncertain rustling of each purple curtain thrilled me—filled me with fantastic terrors never felt before.",
                "Take thy beak from out my heart, and take thy form from off my door!",
                "Prophet!” said I, “thing of evil!—prophet still, if bird or devil!—Whether Tempter sent, or whether tempest tossed thee here ashore, Desolate yet all undaunted, on this desert land enchanted—On this home by Horror haunted—tell me truly, I implore—is there—is there balm in Gilead?—tell me—tell me, I implore.'"
            ],
            "The Tell-Tale Heart" => [
                "True!—nervous—very, very dreadfully nervous I had been and am; but why will you say that I am mad?",
                "It’s the beating of his hideous heart!",
                "I admit the deed!—tear up the planks!—here, here!—it is the beating of his hideous heart!",
                "I heard many things in hell.",
                "I was never kinder to the old man than during the whole week before I killed him."
            ],
            "The Fall of the House of Usher" => [
                "During the whole of a dull, dark, and soundless day in the autumn of the year, when the clouds hung oppressively low in the heavens, I had been passing alone, on horseback, through a singularly dreary tract of country.",
                "From that chamber, and from that mansion, I fled aghast.",
                "I felt that I breathed an atmosphere of sorrow.",
                "I know not how it was—but, with the first glimpse of the building, a sense of insufferable gloom pervaded my spirit.",
                "And the gray walls and the gray tombstones, and the trees with their gray, skeleton branches, all seemed to be shrouded in a uniform, melancholy gloom."
            ],
            "The Pit and the Pendulum" => [
                "I WAS sick—sick unto death with that long agony; and when they at length unbound me, and I was permitted to sit, I felt that my senses were leaving me.",
                "Down—steadily down it crept.",
                "The intensity of the darkness seemed to oppress and stifle me.",
                "I felt that I lay upon my back, unbound.",
                "The figure was tall and gaunt, and shrouded from head to foot in the habiliments of the grave. The mask which concealed the visage was made so nearly to resemble the countenance of a stiffened corpse that the closest scrutiny must have had difficulty in detecting the cheat."
            ],
            "The Masque of the Red Death" => [
                "There were sharp pains, and sudden dizziness, and then profuse bleeding at the pores, with dissolution.",
                "And Darkness and Decay and the Red Death held illimitable dominion over all.",
                "There were buffoons, there were improvisatori, there were ballet-dancers, there were musicians, there was Beauty, there was wine. All these and security were within. Without was the 'Red Death.'",
                "But the Prince Prospero was happy and dauntless and sagacious.",
                "He had come like a thief in the night. And one by one dropped the revellers in the blood-bedewed halls of their revel, and died each in the despairing posture of his fall."
            ],
            "The Cask of Amontillado" => [
                "The thousand injuries of Fortunato I had borne as I best could, but when he ventured upon insult I vowed revenge.",
                "For the half of a century no mortal has disturbed them. In pace requiescat!",
                "I must not only punish but punish with impunity.",
                "It must be understood that neither by word nor deed had I given Fortunato cause to doubt my good will.",
                "A wrong is unredressed when retribution overtakes its redresser. It is equally unredressed when the avenger fails to make himself felt as such to him who has done the wrong."
            ],
        ],
    ];

    private const ICONS = [
        "howard" => "🐙",
        "edgar" => "🐦",
    ];

    private const AUTHORS = [
        "howard" => "Howard Phillips Lovecraft",
        "edgar" => "Edgar Allan Poe",
    ];

    /**
     * @throws Exception
     */
    public function __invoke(?string $book, ?string $author, bool $all = false): int
    {
        $quotes = $all ? $this->getAllQuotes() : [$this->getRandomQuote()];

        if ($book && $author) {
            Terminal::output()->writeln("<error>Cannot use both --book and --author options</error>");
            return $this->failure();
        }

        if ($book) {
            $quotes = $all ? $this->getAllQuotesFromBook($book) : [$this->getQuoteFromBook($book)];
        }
        if ($author) {
            $quotes = $all ? $this->getAllQuotesFromAuthor($author) : [$this->getQuoteFromAuthor($author)];
        }

        $this->renderQuotes($quotes);

        return $this->success();
    }

    /**
     * @throws Exception
     */
    private function getQuoteFromAuthor(string $author): array
    {
        if (!array_key_exists($author, self::QUOTES)) {
            throw new \RuntimeException("Author not found");
        }

        $book = $this->getRandomBook($author);
        return $this->getQuoteFromBook($book);
    }

    /**
     * @throws Exception
     */
    private function getQuoteFromBook(string $book): array
    {
        foreach (self::QUOTES as $author => $books) {
            if (array_key_exists($book, $books)) {
                $book_quotes = $books[$book];
                return [
                    "author" => $author,
                    "book" => $book,
                    "quote" => $book_quotes[array_rand($book_quotes)]
                ];

            }
        }

        throw new \RuntimeException("Book not found");
    }

    private function getAllQuotesFromAuthor(string $author): array
    {
        if (!array_key_exists($author, self::QUOTES)) {
            throw new \RuntimeException("Author not found");
        }

        $quotes = [];
        foreach (self::QUOTES[$author] as $book => $book_quotes) {
            foreach ($book_quotes as $quote) {
                $quotes[] = [
                    "author" => $author,
                    "book" => $book,
                    "quote" => $quote
                ];
            }
        }

        shuffle($quotes);
        return $quotes;
    }

    private function getAllQuotesFromBook(string $book): array
    {
        foreach (self::QUOTES as $author => $books) {
            if (array_key_exists($book, $books)) {
                $book_quotes = $books[$book];
                $quotes = [];
                foreach ($book_quotes as $quote) {
                    $quotes[] = [
                        "author" => $author,
                        "book" => $book,
                        "quote" => $quote
                    ];
                }
                shuffle($quotes);
                return $quotes;
            }
        }

        throw new \RuntimeException("Book not found");
    }

    private function getAllQuotes(): array
    {
        $quotes = [];
        foreach (self::QUOTES as $author => $books) {
            foreach ($books as $book => $book_quotes) {
                foreach ($book_quotes as $quote) {
                    $quotes[] = [
                        "author" => $author,
                        "book" => $book,
                        "quote" => $quote
                    ];
                }
            }
        }

        shuffle($quotes);
        return $quotes;
    }

    /**
     * @throws Exception
     */
    private function getRandomQuote(): array
    {
        $author = $this->getRandomAuthor();
        $book = $this->getRandomBook($author);
        return $this->getQuoteFromBook($book);
    }

    private function getRandomAuthor(): string
    {
        $authors = array_keys(self::QUOTES);
        shuffle($authors);
        return $authors[0];
    }

    private function getRandomBook(?string $author = null): string
    {
        $author = $author ?? $this->getRandomAuthor();
        $books = array_keys(self::QUOTES[$author]);
        shuffle($books);

        return $books[0];
    }

    private function renderQuote(array $quote): void
    {
        $author = $quote["author"];
        $book = $quote["book"];
        $quote = $quote["quote"];

        $icon = self::ICONS[$author];
        $author_name = self::AUTHORS[$author];

        render(
            "<div class='w-auto mt-1 ml-1 mr-1'>
                    <span class='text-comment italic'>- \"{$quote}\"</span><br><br>
                    <span class='ml-2'><span class='app-icon'>{$icon}</span>{$book}</span> - <span class='text-info'>{$author_name}</span>
                </div>"
        );
    }

    private function renderQuotes(array $quotes): void
    {
        foreach ($quotes as $quote) {
            $this->renderQuote($quote);
        }
    }
}
